/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    // Đúng 3 breakpoint: <640 (mobile) · 640–1024 (tablet) · >1024 (desktop)
    screens: {
      sm: '640px',
      lg: '1025px',
    },
    extend: {
      colors: {
        brand: {
          DEFAULT: '#059669', // Emerald – màu chủ đạo theo C = 1
          dark: '#047857', // dùng cho chữ/nút (tương phản AA trên nền trắng)
          deep: '#064E3B',
          mist: '#D1FAE5',
          tint: '#ECFDF5',
        },
        ink: '#123226',
        muted: '#456055',
        paper: '#F2F6F3',
        marker: '#FFE27A',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'],
        sans: ['"Be Vietnam Pro"', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
