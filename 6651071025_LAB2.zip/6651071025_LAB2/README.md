# 6651071025_LAB2 – Việc IT Xanh (Job Board)

## Biến thể cá nhân hóa (MSSV 6651071025)
- S = 6+6+5+1+0+7+1+0+2+5 = **33**
- D = 33 mod 15 = **3** → Bảng 1 dòng 3: **Tuyển dụng / tìm việc** (tự tạo `src/data/data.json`, 20 mục)
- F = 25 mod 10 = **5** → Bảng 2 dòng 5: **Đa ngôn ngữ VI/EN không reload · So sánh nhiều mục · Skeleton loading**
- C = 6 mod 5 = **1** → Bảng 3 dòng 1: **Emerald (#059669)**

## Chạy dự án
```bash
npm install
npm run dev        # chạy thử
npx tsc --noEmit   # 0 lỗi
npx eslint .       # 0 lỗi, 0 cảnh báo
npm run test       # 7/7 pass
npm run build
```

## Tính năng
- Route: `/` (danh sách), `/item/:id` (chi tiết), `/compare` (so sánh), `*` (404) – điều hướng bằng `<Link>`.
- VI/EN không reload: `src/i18n/` (Context + từ điển + hàm `t`), lưu lựa chọn vào localStorage, cập nhật `<html lang>`.
- So sánh nhiều mục: `src/compare/` (Context), chọn tối đa 3 vị trí, bảng so sánh ở `/compare`.
- Skeleton loading: `src/services/jobs.ts` giả lập API trễ 0,9 giây; `JobCardSkeleton` và skeleton trang chi tiết.
- Màu: `#059669` dùng cho điểm nhấn; chữ/nút dùng `#047857` để đạt tương phản AA trên nền trắng.

## Triển khai
- Vercel: import repo, framework Vite (đã có `vercel.json` rewrite về `index.html`).
- Netlify: có sẵn `public/_redirects`.

## Quy trình git (làm thật trong 5 tiếng, ≥ 14 commit, dạng `[HH:MM] mô tả`)
Gợi ý chia việc: khởi tạo Vite + Tailwind · cấu hình ESLint/Vitest · utils + test · types + data.json · i18n · layout/header · ListPage · skeleton · DetailPage · compare context · ComparePage · a11y · responsive · deploy · Lighthouse/README.
Thư mục `design/` cần có ảnh wireframe (vẽ tay hoặc Figma) trước khi nộp.

## Nội dung file PDF nộp
1. Họ tên, MSSV 6651071025
2. S = 33, D = 3 (Tuyển dụng/tìm việc), F = 5 (VI/EN · So sánh · Skeleton), C = 1 (Emerald #059669)
3. Link GitHub: `6651071025-lab2-job-board`
4. Link web đã deploy
5. Link video demo ≤ 3 phút
6. 4 ảnh chụp: `tsc`, `eslint`, `npm run test` (7/7), Lighthouse Mobile
7. Đoạn giải thích 150–250 từ, tự viết. Ý chính gợi ý cho tính năng VI/EN: từ điển `vi`/`en` cùng kiểu khóa, `LanguageContext` giữ `lang`, hàm `t(key, params)` tra từ điển, đổi `lang` làm React render lại nên không cần tải trang, lưu localStorage để nhớ lựa chọn, cập nhật `document.documentElement.lang`, dữ liệu việc làm có sẵn hai ngôn ngữ.
