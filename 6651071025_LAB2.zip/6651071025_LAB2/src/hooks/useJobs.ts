import { useEffect, useState } from 'react'
import { fetchJobs, peekJobs } from '../services/jobs'
import type { Job } from '../types'

export function useJobs(): { jobs: Job[]; loading: boolean } {
  const [jobs, setJobs] = useState<Job[]>(() => peekJobs() ?? [])
  const [loading, setLoading] = useState<boolean>(() => peekJobs() === null)

  useEffect(() => {
    let active = true
    fetchJobs().then((list) => {
      if (!active) return
      setJobs(list)
      setLoading(false)
    })
    return () => {
      active = false
    }
  }, [])

  return { jobs, loading }
}
