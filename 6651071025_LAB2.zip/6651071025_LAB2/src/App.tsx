import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { CompareProvider } from './compare/CompareProvider'
import { Layout } from './components/Layout'
import { LanguageProvider } from './i18n/LanguageProvider'
import ComparePage from './pages/ComparePage'
import DetailPage from './pages/DetailPage'
import ListPage from './pages/ListPage'
import NotFoundPage from './pages/NotFoundPage'

export default function App() {
  return (
    <LanguageProvider>
      <CompareProvider>
        <BrowserRouter>
          <Routes>
            <Route element={<Layout />}>
              <Route index element={<ListPage />} />
              <Route path="item/:id" element={<DetailPage />} />
              <Route path="compare" element={<ComparePage />} />
              <Route path="*" element={<NotFoundPage />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </CompareProvider>
    </LanguageProvider>
  )
}
