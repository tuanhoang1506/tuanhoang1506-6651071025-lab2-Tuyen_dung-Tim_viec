import type { Job } from '../types'

export function formatDate(iso: string, locale: string): string {
  return new Date(iso).toLocaleDateString(locale, {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    timeZone: 'UTC',
  })
}

export function salaryInMillions(job: Pick<Job, 'salaryMin' | 'salaryMax'>): string {
  return `${job.salaryMin / 1000000}–${job.salaryMax / 1000000}`
}

/** Bỏ dấu tiếng Việt + chữ thường để gõ "lua" vẫn ra "Lúa". */
export function normalizeText(value: string): string {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'd')
    .toLowerCase()
}
