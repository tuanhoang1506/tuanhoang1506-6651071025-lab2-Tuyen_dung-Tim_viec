import type { BenefitKey, City, JobType, Level } from '../types'
import type { DictKey } from '../i18n/dictionary'

export const levelKey: Record<Level, DictKey> = {
  intern: 'levelIntern',
  junior: 'levelJunior',
  mid: 'levelMid',
  senior: 'levelSenior',
}

export const typeKey: Record<JobType, DictKey> = {
  fulltime: 'typeFulltime',
  parttime: 'typeParttime',
  remote: 'typeRemote',
}

export const cityKey: Record<City, DictKey> = {
  hcm: 'cityHcm',
  hn: 'cityHn',
  dn: 'cityDn',
  ct: 'cityCt',
}

export const benefitKey: Record<BenefitKey, DictKey> = {
  insurance: 'benefitInsurance',
  bonus13: 'benefitBonus13',
  laptop: 'benefitLaptop',
  training: 'benefitTraining',
  lunch: 'benefitLunch',
  remote: 'benefitRemote',
  travel: 'benefitTravel',
}
