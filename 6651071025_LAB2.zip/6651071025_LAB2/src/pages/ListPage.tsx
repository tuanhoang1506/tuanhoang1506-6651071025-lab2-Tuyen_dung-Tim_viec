import { useMemo, useState } from 'react'
import { JobCard } from '../components/JobCard'
import { JobCardSkeleton } from '../components/JobCardSkeleton'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { useJobs } from '../hooks/useJobs'
import { useLanguage } from '../i18n/useLanguage'
import type { DictKey } from '../i18n/dictionary'
import { normalizeText } from '../lib/format'
import { levelKey } from '../lib/labels'
import type { Level } from '../types'

type LevelFilter = 'all' | Level

const LEVELS: LevelFilter[] = ['all', 'intern', 'junior', 'mid', 'senior']
const levelFilterKey: Record<LevelFilter, DictKey> = { all: 'levelAll', ...levelKey }
// Mobile 1 cột · tablet 2 cột · desktop 3 cột
const GRID = 'grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3'

export default function ListPage() {
  const { t, lang } = useLanguage()
  const { jobs, loading } = useJobs()
  const [query, setQuery] = useState('')
  const [level, setLevel] = useState<LevelFilter>('all')

  useDocumentTitle(t('appName'))

  const filtered = useMemo(() => {
    const needle = normalizeText(query.trim())
    return jobs.filter((job) => {
      if (level !== 'all' && job.level !== level) return false
      if (!needle) return true
      const haystack = normalizeText([job.title.vi, job.title.en, job.company, ...job.skills].join(' '))
      return haystack.includes(needle)
    })
  }, [jobs, query, level])

  function clearFilters() {
    setQuery('')
    setLevel('all')
  }

  return (
    <>
      <section className="border-b border-ink/10 bg-brand-tint">
        <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
          <h1 className="max-w-2xl text-4xl font-bold leading-tight tracking-tight text-brand-deep sm:text-5xl">
            {t('heroTitle')}
          </h1>
          <p className="mt-3 max-w-xl text-muted">{t('heroSub')}</p>
          <div className="mt-6 max-w-xl">
            <label htmlFor="job-search" className="mb-1 block text-sm font-medium">
              {t('searchLabel')}
            </label>
            <input
              id="job-search"
              type="search"
              lang={lang}
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={t('searchPlaceholder')}
              className="min-h-[48px] w-full rounded-xl border border-ink/30 bg-white px-4 text-base placeholder:text-muted"
            />
          </div>
        </div>
      </section>

      <section aria-labelledby="results-heading" className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        <h2 id="results-heading" className="sr-only">
          {t('navJobs')}
        </h2>

        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div role="group" aria-label={t('levelFilter')} className="flex flex-wrap gap-2">
            {LEVELS.map((item) => (
              <button
                key={item}
                type="button"
                aria-pressed={level === item}
                onClick={() => setLevel(item)}
                className={`min-h-[44px] rounded-full border px-4 text-sm font-medium ${
                  level === item
                    ? 'border-brand-dark bg-brand-dark text-white'
                    : 'border-ink/30 bg-white text-ink hover:border-brand-dark'
                }`}
              >
                {t(levelFilterKey[item])}
              </button>
            ))}
          </div>
          <p role="status" className="text-sm text-muted">
            {loading ? t('loading') : t('resultCount', { n: filtered.length })}
          </p>
        </div>

        {loading ? (
          <ul aria-busy="true" className={GRID}>
            {Array.from({ length: 6 }, (_, index) => (
              <JobCardSkeleton key={index} />
            ))}
          </ul>
        ) : filtered.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-ink/30 bg-white p-8">
            <p className="font-display text-xl font-bold">{t('emptyTitle')}</p>
            <p className="mt-1 text-muted">{t('emptyHint')}</p>
            <button
              type="button"
              onClick={clearFilters}
              className="mt-4 min-h-[44px] rounded-lg bg-brand-dark px-5 font-medium text-white hover:bg-brand-deep"
            >
              {t('clearFilters')}
            </button>
          </div>
        ) : (
          <ul className={GRID}>
            {filtered.map((job) => (
              <JobCard key={job.id} job={job} />
            ))}
          </ul>
        )}
      </section>
    </>
  )
}
