import { Link } from 'react-router-dom'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { useLanguage } from '../i18n/useLanguage'

export default function NotFoundPage() {
  const { t } = useLanguage()
  useDocumentTitle(t('pageNotFoundTitle'))

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="text-3xl font-bold">{t('pageNotFoundTitle')}</h1>
      <Link to="/" className="mt-4 inline-flex min-h-[44px] items-center font-medium text-brand-dark underline underline-offset-4">
        {t('backToList')}
      </Link>
    </div>
  )
}
