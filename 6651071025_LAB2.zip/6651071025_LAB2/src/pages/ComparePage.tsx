import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { useCompare } from '../compare/useCompare'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { useJobs } from '../hooks/useJobs'
import type { DictKey } from '../i18n/dictionary'
import { useLanguage } from '../i18n/useLanguage'
import { formatDate } from '../lib/format'
import { benefitKey, cityKey, levelKey, typeKey } from '../lib/labels'
import type { Job } from '../types'
import { formatCurrency } from '../utils'

export default function ComparePage() {
  const { t, lang, locale } = useLanguage()
  const { ids, remove } = useCompare()
  const { jobs, loading } = useJobs()

  useDocumentTitle(t('compareTitle'))

  const selected = ids
    .map((id) => jobs.find((job) => job.id === id))
    .filter((job): job is Job => job !== undefined)

  const rows: { label: DictKey; render: (job: Job) => ReactNode }[] = [
    { label: 'rowCompany', render: (job) => job.company },
    { label: 'rowLocation', render: (job) => t(cityKey[job.city]) },
    { label: 'rowType', render: (job) => t(typeKey[job.type]) },
    { label: 'rowLevel', render: (job) => t(levelKey[job.level]) },
    {
      label: 'rowSalary',
      render: (job) => (
        <span className="bg-[linear-gradient(transparent_40%,#FFE27A_40%)] px-1 font-medium">
          {formatCurrency(job.salaryMin)} – {formatCurrency(job.salaryMax)}
        </span>
      ),
    },
    {
      label: 'rowExperience',
      render: (job) => (job.experience === 0 ? t('noExperience') : t('years', { n: job.experience })),
    },
    { label: 'rowSkills', render: (job) => job.skills.join(', ') },
    {
      label: 'rowBenefits',
      render: (job) => (
        <ul className="space-y-1">
          {job.benefits.map((benefit) => (
            <li key={benefit}>{t(benefitKey[benefit])}</li>
          ))}
        </ul>
      ),
    },
    { label: 'rowDeadline', render: (job) => formatDate(job.deadline, locale) },
  ]

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <Link to="/" className="inline-flex min-h-[44px] items-center text-sm font-medium text-brand-dark underline underline-offset-4">
        {t('backToList')}
      </Link>
      <h1 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">{t('compareTitle')}</h1>

      {loading ? (
        <div
          aria-busy="true"
          className="mt-6 h-72 animate-pulse rounded-2xl bg-ink/10 motion-reduce:animate-none"
        />
      ) : selected.length < 2 ? (
        <p className="mt-4 rounded-2xl border border-dashed border-ink/30 bg-white p-6 text-muted">
          {t('compareNeedTwo')}
        </p>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-2xl border border-ink/10 bg-white">
          <table className="w-full min-w-[640px] border-collapse text-left text-sm">
            <caption className="sr-only">{t('compareTitle')}</caption>
            <thead>
              <tr className="border-b border-ink/10">
                <th scope="col" className="w-36 p-4 align-bottom">
                  <span className="sr-only">{t('compareCriteria')}</span>
                </th>
                {selected.map((job) => (
                  <th key={job.id} scope="col" className="p-4 align-top">
                    <div className="flex items-start justify-between gap-2">
                      <Link
                        to={`/item/${job.id}`}
                        className="font-display text-base font-bold text-brand-deep underline-offset-4 hover:underline"
                      >
                        {job.title[lang]}
                      </Link>
                      <button
                        type="button"
                        onClick={() => remove(job.id)}
                        aria-label={t('removeItem', { name: job.title[lang] })}
                        className="grid h-10 w-10 shrink-0 place-items-center rounded-lg text-lg text-ink hover:bg-brand-tint"
                      >
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.label} className="border-b border-ink/10 last:border-b-0">
                  <th scope="row" className="p-4 align-top font-medium text-muted">
                    {t(row.label)}
                  </th>
                  {selected.map((job) => (
                    <td key={job.id} className="p-4 align-top">
                      {row.render(job)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
