import { Link, useParams } from 'react-router-dom'
import { Avatar } from '../components/Avatar'
import { useCompare } from '../compare/useCompare'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { useJobs } from '../hooks/useJobs'
import { useLanguage } from '../i18n/useLanguage'
import { formatDate } from '../lib/format'
import { benefitKey, cityKey, levelKey, typeKey } from '../lib/labels'
import { formatCurrency } from '../utils'

function DetailSkeleton() {
  return (
    <div
      aria-busy="true"
      className="mx-auto max-w-3xl animate-pulse px-4 py-8 motion-reduce:animate-none sm:px-6"
    >
      <div className="h-4 w-40 rounded bg-ink/10" />
      <div className="mt-8 h-10 w-10 rounded-lg bg-ink/10" />
      <div className="mt-4 h-9 w-3/4 rounded bg-ink/10" />
      <div className="mt-4 h-7 w-1/2 rounded bg-ink/10" />
      <div className="mt-8 h-32 w-full rounded-2xl bg-ink/10" />
      <div className="mt-6 h-24 w-full rounded-2xl bg-ink/10" />
    </div>
  )
}

export default function DetailPage() {
  const { id } = useParams<{ id: string }>()
  const { t, lang, locale } = useLanguage()
  const { jobs, loading } = useJobs()
  const { has, toggle, isFull } = useCompare()

  const job = jobs.find((item) => item.id === id)
  useDocumentTitle(job ? `${job.title[lang]} – ${job.company}` : t('appName'))

  if (loading) return <DetailSkeleton />

  if (!job) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <h1 className="text-3xl font-bold">{t('notFoundTitle')}</h1>
        <p className="mt-2 text-muted">{t('notFoundHint')}</p>
        <Link to="/" className="mt-4 inline-block font-medium text-brand-dark underline underline-offset-4">
          {t('backToList')}
        </Link>
      </div>
    )
  }

  const selected = has(job.id)
  const locked = !selected && isFull
  const facts: { label: Parameters<typeof t>[0]; value: string }[] = [
    { label: 'rowLocation', value: t(cityKey[job.city]) },
    { label: 'rowType', value: t(typeKey[job.type]) },
    { label: 'rowLevel', value: t(levelKey[job.level]) },
    {
      label: 'rowExperience',
      value: job.experience === 0 ? t('noExperience') : t('years', { n: job.experience }),
    },
    { label: 'rowPosted', value: formatDate(job.posted, locale) },
    { label: 'rowDeadline', value: formatDate(job.deadline, locale) },
  ]

  return (
    <article className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
      <Link to="/" className="inline-flex min-h-[44px] items-center text-sm font-medium text-brand-dark underline underline-offset-4">
        {t('backToList')}
      </Link>

      <div className="mt-4 flex items-center gap-3">
        <Avatar name={job.company} />
        <p className="text-muted">{job.company}</p>
      </div>
      <h1 className="mt-3 text-3xl font-bold leading-tight tracking-tight sm:text-4xl">{job.title[lang]}</h1>

      <p className="mt-4 font-display text-xl font-bold">
        <span className="bg-[linear-gradient(transparent_40%,#FFE27A_40%)] px-1">
          {formatCurrency(job.salaryMin)} – {formatCurrency(job.salaryMax)}
        </span>
      </p>

      <dl className="mt-6 grid grid-cols-1 gap-4 rounded-2xl border border-ink/10 bg-white p-5 sm:grid-cols-2">
        {facts.map((fact) => (
          <div key={fact.label}>
            <dt className="text-sm text-muted">{t(fact.label)}</dt>
            <dd className="font-medium">{fact.value}</dd>
          </div>
        ))}
      </dl>

      <section className="mt-8" aria-labelledby="about-heading">
        <h2 id="about-heading" className="text-xl font-bold">
          {t('aboutRole')}
        </h2>
        <p className="mt-2 max-w-[65ch] leading-relaxed">{job.summary[lang]}</p>
      </section>

      <section className="mt-8" aria-labelledby="skills-heading">
        <h2 id="skills-heading" className="text-xl font-bold">
          {t('skillsTitle')}
        </h2>
        <ul className="mt-3 flex flex-wrap gap-2">
          {job.skills.map((skill) => (
            <li key={skill} className="rounded-full bg-brand-mist px-3 py-1 text-sm text-brand-deep">
              {skill}
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-8" aria-labelledby="benefits-heading">
        <h2 id="benefits-heading" className="text-xl font-bold">
          {t('benefitsTitle')}
        </h2>
        <ul className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {job.benefits.map((benefit) => (
            <li key={benefit} className="rounded-lg border border-ink/10 bg-white px-4 py-2">
              {t(benefitKey[benefit])}
            </li>
          ))}
        </ul>
      </section>

      <button
        type="button"
        onClick={() => toggle(job.id)}
        disabled={locked}
        className={`mt-8 min-h-[48px] rounded-xl px-6 font-medium ${
          selected
            ? 'border-2 border-brand-dark bg-white text-brand-deep'
            : locked
              ? 'cursor-not-allowed bg-ink/10 text-muted'
              : 'bg-brand-dark text-white hover:bg-brand-deep'
        }`}
      >
        {selected ? t('inCompare') : locked ? t('compareFull') : t('addCompare')}
      </button>
    </article>
  )
}
