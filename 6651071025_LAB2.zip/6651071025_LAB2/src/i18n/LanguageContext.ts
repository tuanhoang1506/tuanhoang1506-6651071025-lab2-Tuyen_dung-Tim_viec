import { createContext } from 'react'
import type { Lang } from '../types'
import type { DictKey } from './dictionary'

export interface LanguageContextValue {
  lang: Lang
  locale: string
  setLang: (lang: Lang) => void
  t: (key: DictKey, params?: Record<string, string | number>) => string
}

export const LanguageContext = createContext<LanguageContextValue | null>(null)
