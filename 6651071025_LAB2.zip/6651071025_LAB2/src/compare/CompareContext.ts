import { createContext } from 'react'

export const MAX_COMPARE = 3

export interface CompareContextValue {
  ids: string[]
  toggle: (id: string) => void
  remove: (id: string) => void
  clear: () => void
  has: (id: string) => boolean
  isFull: boolean
}

export const CompareContext = createContext<CompareContextValue | null>(null)
