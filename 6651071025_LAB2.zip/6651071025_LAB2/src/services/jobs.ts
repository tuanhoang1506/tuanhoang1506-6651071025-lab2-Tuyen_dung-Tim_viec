import raw from '../data/data.json'
import type { Job } from '../types'

const allJobs = raw as unknown as Job[]
let cache: Job[] | null = null

/** Giả lập gọi API: trễ ~0,9 giây ở lần đầu để thấy skeleton loading. */
export function fetchJobs(): Promise<Job[]> {
  if (cache) return Promise.resolve(cache)
  return new Promise((resolve) => {
    setTimeout(() => {
      cache = allJobs
      resolve(allJobs)
    }, 900)
  })
}

export function peekJobs(): Job[] | null {
  return cache
}
