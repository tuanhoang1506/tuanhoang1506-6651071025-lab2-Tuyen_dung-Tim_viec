import { Link, NavLink } from 'react-router-dom'
import logo from '../assets/logo.svg'
import { useLanguage } from '../i18n/useLanguage'
import { useCompare } from '../compare/useCompare'
import type { Lang } from '../types'

const LANGS: { code: Lang; label: string }[] = [
  { code: 'vi', label: 'VI' },
  { code: 'en', label: 'EN' },
]

function navClass({ isActive }: { isActive: boolean }): string {
  return `inline-flex min-h-[44px] items-center gap-2 rounded-lg px-3 text-sm font-medium ${
    isActive ? 'bg-brand-mist text-brand-deep' : 'text-ink hover:bg-brand-tint'
  }`
}

export function Header() {
  const { t, lang, setLang } = useLanguage()
  const { ids } = useCompare()

  return (
    <header className="border-b border-ink/10 bg-paper">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-4 gap-y-2 px-4 py-2 sm:px-6">
        <Link to="/" className="flex min-h-[44px] items-center gap-2 font-display text-xl font-bold text-brand-deep">
          <img src={logo} alt={t('logoAlt')} width={32} height={32} />
          {t('appName')}
        </Link>

        <div className="flex flex-wrap items-center gap-2">
          <nav aria-label={t('navLabel')} className="flex items-center gap-1">
            <NavLink to="/" end className={navClass}>
              {t('navJobs')}
            </NavLink>
            <NavLink to="/compare" className={navClass}>
              {t('navCompare')}
              {ids.length > 0 && (
                <span className="rounded-full bg-brand-dark px-2 text-xs text-white">{ids.length}</span>
              )}
            </NavLink>
          </nav>

          <div role="group" aria-label={t('langLabel')} className="flex rounded-lg border border-ink/20 bg-white p-0.5">
            {LANGS.map((item) => (
              <button
                key={item.code}
                type="button"
                lang={item.code}
                aria-pressed={lang === item.code}
                onClick={() => setLang(item.code)}
                className={`min-h-[40px] min-w-[44px] rounded-md px-3 text-sm font-semibold ${
                  lang === item.code ? 'bg-brand-dark text-white' : 'text-ink hover:bg-brand-tint'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </header>
  )
}
