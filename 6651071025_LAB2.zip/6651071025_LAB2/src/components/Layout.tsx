import { useEffect } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import { useLanguage } from '../i18n/useLanguage'
import { CompareBar } from './CompareBar'
import { Header } from './Header'

export function Layout() {
  const { t } = useLanguage()
  const { pathname } = useLocation()

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])

  return (
    <>
      <button
        type="button"
        onClick={() => document.getElementById('main')?.focus()}
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-brand-deep focus:px-4 focus:py-2 focus:text-white"
      >
        {t('skipToContent')}
      </button>
      <Header />
      <main id="main" tabIndex={-1} className="min-h-[70vh] pb-28 focus:outline-none">
        <Outlet />
      </main>
      <CompareBar />
    </>
  )
}
