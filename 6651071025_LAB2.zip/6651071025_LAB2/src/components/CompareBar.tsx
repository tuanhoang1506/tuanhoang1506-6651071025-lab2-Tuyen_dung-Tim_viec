import { Link, useLocation } from 'react-router-dom'
import { useLanguage } from '../i18n/useLanguage'
import { useCompare } from '../compare/useCompare'

export function CompareBar() {
  const { t } = useLanguage()
  const { ids, clear } = useCompare()
  const { pathname } = useLocation()

  if (ids.length === 0 || pathname === '/compare') return null
  const ready = ids.length >= 2

  return (
    <div
      role="region"
      aria-label={t('navCompare')}
      className="fixed inset-x-0 bottom-0 z-20 border-t border-ink/10 bg-white shadow-[0_-4px_16px_rgba(18,50,38,0.08)]"
    >
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <div>
          <p className="font-medium">{t('compareBarCount', { n: ids.length })}</p>
          {!ready && <p className="text-sm text-muted">{t('compareBarHint')}</p>}
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={clear}
            className="min-h-[44px] rounded-lg px-3 text-sm font-medium text-brand-dark underline underline-offset-4"
          >
            {t('compareClear')}
          </button>
          {ready ? (
            <Link
              to="/compare"
              className="inline-flex min-h-[44px] items-center rounded-lg bg-brand-dark px-5 font-medium text-white hover:bg-brand-deep"
            >
              {t('compareNow')}
            </Link>
          ) : (
            <span
              aria-disabled="true"
              className="inline-flex min-h-[44px] items-center rounded-lg bg-ink/10 px-5 font-medium text-muted"
            >
              {t('compareNow')}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}
