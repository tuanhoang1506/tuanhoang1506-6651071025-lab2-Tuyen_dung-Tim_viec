export function Avatar({ name }: { name: string }) {
  return (
    <span
      aria-hidden="true"
      className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-brand-mist font-display text-lg font-bold text-brand-deep"
    >
      {name.charAt(0)}
    </span>
  )
}
