import { Link } from 'react-router-dom'
import type { Job } from '../types'
import { useLanguage } from '../i18n/useLanguage'
import { useCompare } from '../compare/useCompare'
import { cityKey, levelKey, typeKey } from '../lib/labels'
import { salaryInMillions } from '../lib/format'
import { Avatar } from './Avatar'

export function JobCard({ job }: { job: Job }) {
  const { t, lang } = useLanguage()
  const { has, toggle, isFull } = useCompare()
  const selected = has(job.id)
  const locked = !selected && isFull

  return (
    <li
      className={`relative flex flex-col gap-3 rounded-2xl border bg-white p-5 transition-shadow hover:shadow-md ${
        selected ? 'border-brand-dark ring-2 ring-brand/30' : 'border-ink/10'
      }`}
    >
      <div className="flex items-center gap-3">
        <Avatar name={job.company} />
        <p className="text-sm text-muted">{job.company}</p>
      </div>

      <h2 className="text-lg font-bold leading-snug">
        <Link to={`/item/${job.id}`} className="after:absolute after:inset-0 hover:text-brand-dark">
          {job.title[lang]}
        </Link>
      </h2>

      <p className="flex flex-wrap gap-2 text-xs">
        <span className="rounded-full bg-brand-tint px-2.5 py-1 text-brand-deep">{t(levelKey[job.level])}</span>
        <span className="rounded-full bg-brand-tint px-2.5 py-1 text-brand-deep">{t(typeKey[job.type])}</span>
        <span className="rounded-full bg-brand-tint px-2.5 py-1 text-brand-deep">{t(cityKey[job.city])}</span>
      </p>

      <p className="font-display text-lg font-bold">
        <span className="bg-[linear-gradient(transparent_40%,#FFE27A_40%)] px-1">
          {salaryInMillions(job)} {t('salaryUnit')}
        </span>
      </p>

      <p className="text-sm text-muted">{job.skills.slice(0, 3).join(', ')}</p>

      <label
        className={`relative z-10 mt-auto flex min-h-[44px] items-center gap-2 text-sm font-medium ${
          locked ? 'cursor-not-allowed text-muted' : 'cursor-pointer text-brand-deep'
        }`}
      >
        <input
          type="checkbox"
          checked={selected}
          disabled={locked}
          onChange={() => toggle(job.id)}
          className="h-5 w-5 accent-brand-dark"
        />
        {selected ? t('inCompare') : locked ? t('compareFull') : t('addCompare')}
      </label>
    </li>
  )
}
