export function JobCardSkeleton() {
  return (
    <li
      aria-hidden="true"
      className="flex animate-pulse flex-col gap-3 rounded-2xl border border-ink/10 bg-white p-5 motion-reduce:animate-none"
    >
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 rounded-lg bg-ink/10" />
        <div className="h-4 w-28 rounded bg-ink/10" />
      </div>
      <div className="h-5 w-4/5 rounded bg-ink/10" />
      <div className="flex gap-2">
        <div className="h-6 w-16 rounded-full bg-ink/10" />
        <div className="h-6 w-24 rounded-full bg-ink/10" />
        <div className="h-6 w-20 rounded-full bg-ink/10" />
      </div>
      <div className="h-6 w-1/2 rounded bg-ink/10" />
      <div className="h-4 w-3/4 rounded bg-ink/10" />
      <div className="mt-2 h-5 w-32 rounded bg-ink/10" />
    </li>
  )
}
