export type Lang = 'vi' | 'en'
export type Localized = Record<Lang, string>
export type City = 'hcm' | 'hn' | 'dn' | 'ct'
export type JobType = 'fulltime' | 'parttime' | 'remote'
export type Level = 'intern' | 'junior' | 'mid' | 'senior'
export type BenefitKey = 'insurance' | 'bonus13' | 'laptop' | 'training' | 'lunch' | 'remote' | 'travel'

export interface Job {
  id: string
  title: Localized
  company: string
  city: City
  type: JobType
  level: Level
  salaryMin: number
  salaryMax: number
  experience: number
  skills: string[]
  benefits: BenefitKey[]
  summary: Localized
  posted: string
  deadline: string
}
